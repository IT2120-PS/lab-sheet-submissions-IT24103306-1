# Load required library
library(readr)

# Set working directory to Desktop
setwd("~/Desktop")

# Import the dataset
data <- read_csv("Exercise.txt")

# View the dataset
View(data)

# Check the structure of the dataset
str(data)

# Boxplot of Sales_X1
boxplot(data$Sales_X1, main = "Boxplot of Sales", ylab = "Sales",col = "#4C78A8",border = "black")

# Five-number summary for Advertising_X2
summary(data$Advertising_X2)

# IQR for Advertising_X2
IQR(data$Advertising_X2)

# Function to detect outliers
find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR <- Q3 - Q1
  lower_bound <- Q1 - 1.5 * IQR
  upper_bound <- Q3 + 1.5 * IQR
  return(x[x < lower_bound | x > upper_bound])
}

# Check for outliers in Years_X3
find_outliers(data$Years_X3)